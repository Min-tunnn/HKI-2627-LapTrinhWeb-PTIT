<?php
// Cấu hình ứng dụng. Khi đưa lên hosting chỉ cần sửa tệp này.

define('APP_NAME', 'MiniShop');
define('APP_DEBUG', true);          // true: hiện lỗi chi tiết (chỉ dùng khi phát triển)
define('BASE_URL', '/minishop/');   // đường dẫn gốc của website, luôn kết thúc bằng dấu /

// Cơ sở dữ liệu
define('DB_HOST', '127.0.0.1');
define('DB_PORT', '3306'); // Nếu MySQL dùng cổng 3307, đổi tại đây.
define('DB_NAME', 'minishop');
define('DB_USER', 'root');
define('DB_PASS', '');
