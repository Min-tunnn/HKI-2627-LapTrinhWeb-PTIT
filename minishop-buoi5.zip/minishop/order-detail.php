<?php
require __DIR__ . '/includes/init.php';
require_login();

$id = (int) ($_GET['id'] ?? 0);

$stmt = $pdo->prepare('SELECT * FROM orders WHERE id = ?');
$stmt->execute([$id]);
$order = $stmt->fetch();

// Chỉ chủ đơn hàng hoặc quản trị viên được xem.
// Đơn không tồn tại và đơn của người khác đều trả về 404 như nhau.
if (!$order || ((int)$order['user_id'] !== (int)current_user()['id'] && !is_admin())) {
    http_response_code(404);
    $pageTitle = 'Không tìm thấy đơn hàng';
    require __DIR__ . '/includes/header.php';
    echo '<h2>Không tìm thấy đơn hàng</h2>';
    require __DIR__ . '/includes/footer.php';
    exit;
}

$stmt = $pdo->prepare(
    'SELECT product_name, price, quantity FROM order_items WHERE order_id = ? ORDER BY id'
);
$stmt->execute([$id]);
$items = $stmt->fetchAll();

// Hủy đơn bằng POST; chỉ chủ đơn được hủy và chỉ khi đang pending.
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    if (($_POST['action'] ?? '') !== 'cancel') {
        http_response_code(400);
        exit('Thao tác không hợp lệ.');
    }
    if ((int)$order['user_id'] !== (int)current_user()['id']) {
        http_response_code(403);
        exit('Bạn không có quyền hủy đơn này.');
    }
    try {
        $pdo->beginTransaction();
        $update = $pdo->prepare("UPDATE orders SET status = 'cancelled' WHERE id = ? AND user_id = ? AND status = 'pending'");
        $update->execute([$id, current_user()['id']]);
        if ($update->rowCount() !== 1) {
            $pdo->rollBack();
            set_flash('error', 'Chỉ có thể hủy đơn đang chờ xử lý.');
            redirect('order-detail.php?id=' . $id);
        }
        // Trả lại tồn kho đúng số lượng đã mua, cùng một giao dịch.
        $restore = $pdo->prepare('UPDATE products SET stock = stock + ? WHERE id = ?');
        $detail = $pdo->prepare('SELECT product_id, quantity FROM order_items WHERE order_id = ?');
        $detail->execute([$id]);
        foreach ($detail->fetchAll() as $line) {
            $restore->execute([(int)$line['quantity'], (int)$line['product_id']]);
        }
        $pdo->commit();
        set_flash('success', 'Đã hủy đơn hàng và hoàn lại tồn kho.');
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        throw $e;
    }
    redirect('order-detail.php?id=' . $id);
}

$pageTitle = 'Đơn hàng #' . $order['id'];
require __DIR__ . '/includes/header.php';
?>
<h2>Đơn hàng #<?= $order['id'] ?></h2>

<table>
    <tbody>
        <tr>
            <th>Ngày đặt</th>
            <td><?= date('d/m/Y H:i', strtotime($order['created_at'])) ?></td>
        </tr>
        <tr>
            <th>Trạng thái</th>
            <td><?= e(order_status_label($order['status'])) ?></td>
        </tr>
        <tr>
            <th>Người nhận</th>
            <td><?= e($order['fullname']) ?> - <?= e($order['phone']) ?></td>
        </tr>
        <tr>
            <th>Địa chỉ</th>
            <td><?= e($order['address']) ?></td>
        </tr>
        <tr>
            <th>Ghi chú</th>
            <td><?= nl2br(e($order['note'])) ?></td>
        </tr>
    </tbody>
</table>

<?php if ($order['status'] === 'pending' && (int)$order['user_id'] === (int)current_user()['id']): ?>
<form method="post" action="<?= url('order-detail.php?id=' . $id) ?>" onsubmit="return confirm('Bạn có chắc muốn hủy đơn hàng này?');">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="cancel">
    <button style="margin-top: 5px;" class="btn btn-danger" type="submit">Hủy đơn</button>
</form>
<?php endif; ?>
<h3>Sản phẩm</h3>
<table>
    <thead>
        <tr>
            <th>Sản phẩm</th>
            <th>Đơn giá</th>
            <th>Số lượng</th>
            <th>Thành tiền</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($items as $item): ?>
            <tr>
                <td><?= e($item['product_name']) ?></td>
                <td><?= format_price($item['price']) ?></td>
                <td><?= $item['quantity'] ?></td>
                <td><?= format_price($item['price'] * $item['quantity']) ?></td>
            </tr>
        <?php endforeach; ?>
    </tbody>
    <tfoot>
        <tr>
            <th colspan="3">Tổng cộng</th>
            <th><?= format_price($order['total']) ?></th>
        </tr>
    </tfoot>
</table>

<p><a href="<?= url(is_admin() ? 'admin/orders.php' : 'orders.php') ?>">&laquo; Danh sách đơn hàng</a></p>

<?php require __DIR__ . '/includes/footer.php'; ?>
