<?php
require __DIR__ . '/includes/init.php';
$errors = [];
$fullname = is_logged_in() ? (string)current_user()['fullname'] : '';
$email = ''; $subject = ''; $message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $fullname = trim((string)($_POST['fullname'] ?? ''));
    $email = trim((string)($_POST['email'] ?? ''));
    $subject = trim((string)($_POST['subject'] ?? ''));
    $message = trim((string)($_POST['message'] ?? ''));
    if (mb_strlen($fullname) < 2 || mb_strlen($fullname) > 100) $errors['fullname'] = 'Họ tên phải từ 2 đến 100 ký tự.';
    if (mb_strlen($email) > 150 || !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors['email'] = 'Email không hợp lệ.';
    if (mb_strlen($subject) < 2 || mb_strlen($subject) > 200) $errors['subject'] = 'Tiêu đề phải từ 2 đến 200 ký tự.';
    if (mb_strlen($message) < 5 || mb_strlen($message) > 5000) $errors['message'] = 'Nội dung phải từ 5 đến 5000 ký tự.';
    if (!$errors) {
        $stmt = $pdo->prepare('INSERT INTO contacts (fullname, email, subject, message) VALUES (?, ?, ?, ?)');
        $stmt->execute([$fullname, $email, $subject, $message]);
        set_flash('success', 'Đã gửi liên hệ thành công.');
        redirect('contact.php');
    }
}
$pageTitle = 'Liên hệ';
require __DIR__ . '/includes/header.php';
?>
<h2>Liên hệ</h2>
<form action="<?= url('contact.php') ?>" method="post" class="form">
    <?= csrf_field() ?>
    <?php foreach (['fullname'=>'Họ và tên', 'email'=>'Email', 'subject'=>'Tiêu đề', 'message'=>'Nội dung'] as $field => $label): ?>
    <p><label for="<?= $field ?>"><?= $label ?></label><br>
    <?php if ($field === 'message'): ?>
        <textarea id="message" name="message" rows="5" required maxlength="5000"><?= e($message) ?></textarea>
    <?php else: ?>
        <input type="<?= $field === 'email' ? 'email' : 'text' ?>" id="<?= $field ?>" name="<?= $field ?>" value="<?= e($$field) ?>" required>
    <?php endif; ?>
    <span class="error"><?= e($errors[$field] ?? '') ?></span></p>
    <?php endforeach; ?>
    <p><button type="submit" class="btn">Gửi</button></p>
</form>
<?php require __DIR__ . '/includes/footer.php'; ?>
