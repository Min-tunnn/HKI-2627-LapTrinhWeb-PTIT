<?php
require __DIR__ . '/includes/init.php';
require_login();
$stmt = $pdo->prepare('SELECT fullname, phone, address FROM users WHERE id = ?');
$stmt->execute([current_user()['id']]);
$user = $stmt->fetch();
if (!$user) {
    unset($_SESSION['user']);
    redirect('login.php');
}
$fullname = $user['fullname'];
$phone = $user['phone'];
$address = $user['address'];
$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $fullname = trim((string)($_POST['fullname'] ?? ''));
    $phone = trim((string)($_POST['phone'] ?? ''));
    $address = trim((string)($_POST['address'] ?? ''));
    if (mb_strlen($fullname) < 2 || mb_strlen($fullname) > 100) $errors['fullname'] = 'Họ tên phải từ 2 đến 100 ký tự.';
    if (!preg_match('/^0[0-9]{9}$/', $phone)) $errors['phone'] = 'Số điện thoại phải gồm 10 chữ số và bắt đầu bằng 0.';
    if (mb_strlen($address) > 255) $errors['address'] = 'Địa chỉ tối đa 255 ký tự.';
    if (!$errors) {
        $stmt = $pdo->prepare('UPDATE users SET fullname = ?, phone = ?, address = ? WHERE id = ?');
        $stmt->execute([$fullname, $phone, $address, current_user()['id']]);
        $_SESSION['user']['fullname'] = $fullname;
        set_flash('success', 'Cập nhật tài khoản thành công.');
        redirect('account.php');
    }
}
$pageTitle = 'Tài khoản';
require __DIR__ . '/includes/header.php';
?>
<h2>Thông tin tài khoản</h2>
<form method="post" action="<?= url('account.php') ?>" class="form">
    <?= csrf_field() ?>
    <p><label for="fullname">Họ tên</label><br><input id="fullname" name="fullname" required maxlength="100" value="<?= e($fullname) ?>"><span class="error"><?= e($errors['fullname'] ?? '') ?></span></p>
    <p><label for="phone">Số điện thoại</label><br><input id="phone" name="phone" type="tel" required value="<?= e($phone) ?>"><span class="error"><?= e($errors['phone'] ?? '') ?></span></p>
    <p><label for="address">Địa chỉ</label><br><textarea id="address" name="address" maxlength="255" rows="3"><?= e($address) ?></textarea><span class="error"><?= e($errors['address'] ?? '') ?></span></p>
    <p><button class="btn" type="submit">Lưu thay đổi</button></p>
</form>
<?php require __DIR__ . '/includes/footer.php'; ?>
