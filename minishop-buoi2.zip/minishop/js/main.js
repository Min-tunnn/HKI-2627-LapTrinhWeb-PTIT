function formatPrice(amount) {
  return amount.toLocaleString("vi-VN") + " đ";
}

"use strict";

const CART_KEY = "minishop_cart";
const USERS_KEY = "minishop_demo_users";
const PRODUCT_LIST = [
  { id: "1", name: "Chuột không dây M1", price: 250000, image: "images/AnhChuot.jpg", description: "Chuột không dây kết nối 2.4GHz, thiết kế đối xứng, phù hợp cho học tập và làm việc." },
  { id: "2", name: "Bàn phím cơ K2", price: 790000, image: "images/BanPhimCo.jpg", description: "Bàn phím cơ phục vụ học tập, làm việc và giải trí." },
  { id: "3", name: "Tai nghe Bluetooth T3", price: 450000, image: "images/TaiNghe.png", description: "Tai nghe Bluetooth tiện lợi cho nghe nhạc và học trực tuyến." },
  { id: "4", name: "USB 64GB U4", price: 150000, image: "images/USB.jpg", description: "USB dung lượng 64GB để lưu trữ tài liệu và dữ liệu cá nhân." },
  { id: "5", name: "Webcam Full HD W5", price: 520000, image: "images/webcam.jpg", description: "Webcam phục vụ họp trực tuyến và học từ xa." },
  { id: "6", name: "Đế tản nhiệt laptop D6", price: 320000, image: "images/TanNhietLapTop.png", description: "Đế tản nhiệt hỗ trợ thông thoáng cho laptop khi sử dụng." }
];

function formatPrice(amount) {
  return new Intl.NumberFormat("vi-VN", { maximumFractionDigits: 0 }).format(amount) + " đ";
}
function readJSON(key, fallback) {
  try { const raw = localStorage.getItem(key); return raw ? JSON.parse(raw) : fallback; }
  catch (error) { console.warn("Không đọc được dữ liệu lưu trữ:", error); return fallback; }
}
function getCart() {
  const stored = readJSON(CART_KEY, {});
  return stored && typeof stored === "object" && !Array.isArray(stored) ? stored : {};
}
function saveCart(cart) { localStorage.setItem(CART_KEY, JSON.stringify(cart)); }
function getProduct(id) { return PRODUCT_LIST.find(product => product.id === String(id)); }
function updateCartCount() {
  const cart = getCart();
  const count = Object.values(cart).reduce((sum, qty) => sum + (Number.isInteger(Number(qty)) && Number(qty) > 0 ? Number(qty) : 0), 0);
  document.querySelectorAll("#cart-count").forEach(el => { el.textContent = String(count); });
}
function addToCart(id, quantity = 1) {
  const product = getProduct(id);
  const qty = Math.max(1, Math.min(99, Math.floor(Number(quantity) || 1)));
  if (!product) return false;
  const cart = getCart();
  cart[product.id] = Math.min(99, Math.max(0, Number(cart[product.id]) || 0) + qty);
  saveCart(cart); updateCartCount(); return true;
}

document.querySelectorAll(".add-to-cart").forEach(button => {
  button.addEventListener("click", () => {
    if (addToCart(button.dataset.id)) {
      const oldText = button.textContent;
      button.textContent = "Đã thêm ✓";
      window.setTimeout(() => { button.textContent = oldText; }, 1200);
    }
  });
});

// Chi tiết sản phẩm theo ?id=...; mặc định hiển thị sản phẩm đầu tiên.
const productDetail = document.querySelector("#product-detail");
if (productDetail) {
  const id = new URLSearchParams(location.search).get("id") || "1";
  const product = getProduct(id);
  document.title = `${product.name} - MiniShop`;
  document.querySelector("#product-name").textContent = product.name;
  document.querySelector("#product-price").textContent = formatPrice(product.price);
  document.querySelector("#product-description").textContent = product.description;
  const image = document.querySelector("#product-image"); image.src = product.image; image.alt = product.name;
  document.querySelector("#product-add-to-cart").addEventListener("click", () => {
    const quantityInput = document.querySelector("#product-quantity");
    const quantity = Number(quantityInput.value);
    const message = document.querySelector("#product-message");
    addToCart(product.id, quantity); message.textContent = `Đã thêm ${quantity} × ${product.name} vào giỏ hàng.`;
  });
}

// Giỏ hàng dựng hoàn toàn từ localStorage.

const cartItems = document.querySelector("#cart-items");
function renderCart() {
  if (!cartItems) return;
  const cart = getCart(); let total = 0; cartItems.replaceChildren();
  const entries = Object.entries(cart).filter(([id, qty]) => getProduct(id) && Number(qty) > 0);
  if (!entries.length) {
    const row = document.createElement("tr"); const cell = document.createElement("td");
    cell.colSpan = 5; cell.textContent = "Giỏ hàng đang trống. Hãy chọn sản phẩm ở trang chủ.";
    row.appendChild(cell); cartItems.appendChild(row);
  }
  entries.forEach(([id, rawQty]) => {
    const product = getProduct(id); const qty = Math.max(1, Math.min(99, Math.floor(Number(rawQty) || 1))); const lineTotal = product.price * qty; total += lineTotal;
    const row = document.createElement("tr");
    const nameCell = document.createElement("td");
    const link = document.createElement("a"); link.href = `product.html?id=${product.id}`; link.textContent = product.name; nameCell.appendChild(link);
    const priceCell = document.createElement("td"); priceCell.textContent = formatPrice(product.price);
    const qtyCell = document.createElement("td"); const input = document.createElement("input"); input.type = "number"; input.className = "qty"; input.min = "1"; input.max = "99"; input.step = "1"; input.value = String(qty); input.setAttribute("aria-label", `Số lượng ${product.name}`); input.dataset.id = product.id; qtyCell.appendChild(input);
    const totalCell = document.createElement("td"); totalCell.className = "line-total"; totalCell.textContent = formatPrice(lineTotal);
    const actionCell = document.createElement("td"); const remove = document.createElement("button"); remove.type = "button"; remove.className = "btn btn-danger remove-item"; remove.dataset.id = product.id; remove.textContent = "Xóa"; actionCell.appendChild(remove);
    row.append(nameCell, priceCell, qtyCell, totalCell, actionCell); cartItems.appendChild(row);
  });
  const totalEl = document.querySelector("#cart-total"); if (totalEl) totalEl.textContent = formatPrice(total);
  updateCartCount();
}
 cartItems.addEventListener("click", event => {
    const button = event.target.closest(".remove-item"); if (!button) return;
    
    const product = getProduct(button.dataset.id);
    const productName = product ? product.name : "Sản phẩm";
    const isConfirmed = confirm(`Bạn có chắc chắn muốn xóa "${productName}" khỏi giỏ hàng không?`);

    if (isConfirmed) {
      const cart = getCart(); 
      delete cart[button.dataset.id]; 
      saveCart(cart); 
      renderCart();
      console.log(`[Giỏ hàng] Đã xác nhận xóa thành công: ${productName} (ID: ${button.dataset.id})`);
    } else {
      console.log(`[Giỏ hàng] Người dùng đã hủy yêu cầu xóa sản phẩm: ${productName}`);
    }
  });

renderCart();

const checkoutButton = document.querySelector("#checkout-button");
if (checkoutButton) checkoutButton.addEventListener("click", () => {
  const cart = getCart(); const hasItems = Object.entries(cart).some(([id, qty]) => getProduct(id) && Number(qty) > 0);
  const message = document.querySelector("#cart-message");
  if (!hasItems) { message.textContent = "Giỏ hàng đang trống, chưa thể đặt hàng."; return; }
  message.textContent = "Đây là bản demo: đơn hàng chưa được gửi đến máy chủ và chưa phát sinh thanh toán. Giỏ hàng được giữ nguyên.";
});

// ===== 4. Form đăng ký: hai mật khẩu phải khớp nhau =====
const registerForm = document.querySelector("#register-form");
if (registerForm) {
  registerForm.addEventListener("submit", function (event) {
    const password = document.querySelector("#password").value;
    const password2 = document.querySelector("#password2").value;
    const error = document.querySelector("#password-error");

    if (password !== password2) {
      event.preventDefault();
      error.textContent = "Hai mật khẩu không khớp nhau.";
    } else {
      error.textContent = "";
    }
  });
}


const contactForm = document.querySelector("#contact-form");

if (contactForm) {
  contactForm.addEventListener("submit", function (event) {
    // 1. Lấy thẻ textarea và thẻ hiển thị thông báo
    const note = document.querySelector("#note");
    const messageEl = document.querySelector("#contact-message");
    
    // Loại bỏ khoảng trắng thừa ở hai đầu nội dung nhập vào
    const content = note.value.trim();

    // 2. Kiểm tra điều kiện độ dài nội dung
    if (content.length < 10) {
      // CHẶN HÀNH VI GỬI FORM (không cho tải lại trang)
      event.preventDefault(); 
      
      // HIỂN THỊ THÔNG BÁO LỖI LÊN MÀN HÌNH
      messageEl.textContent = "Nội dung liên hệ phải có ít nhất 10 ký tự!";
      messageEl.style.color = "red"; // Đổi chữ thành màu đỏ để cảnh báo
      
      // Đưa con trỏ chuột tập trung vào ô nhập liệu bị lỗi
      note.focus();
    } else {
      // Xử lý khi dữ liệu hợp lệ (Dành cho bản demo)
      event.preventDefault(); // Chặn lại để xem thông báo thành công thay vì chuyển trang
      
      messageEl.textContent = "Gửi thông tin liên hệ thành công!";
      messageEl.style.color = "green"; // Đổi chữ thành màu xanh lá
      
      contactForm.reset(); // Xóa sạch dữ liệu vừa nhập trong form
    }
  });
}



updateCartCount();
